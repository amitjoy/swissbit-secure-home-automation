package com.swissbit.server.ws;

public interface Constants {

	public static final String DB_URL = "jdbc:mysql://localhost/spark";
	public static final String IP_ADDRESS = "";
	public static final String MYSQL_PASSWORD = "root";
	public static final String MYSQL_USER = "root";
	public static final int PORT = 4567;

}
