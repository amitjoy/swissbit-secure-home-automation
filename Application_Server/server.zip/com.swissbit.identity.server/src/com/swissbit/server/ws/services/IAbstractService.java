package com.swissbit.server.ws.services;

public interface IAbstractService {
	// Marker Interface
}
